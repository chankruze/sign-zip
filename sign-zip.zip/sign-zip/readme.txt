**NOTE: Do not leave spaces when you name your zip files, if not you will get errors...**

1. Put your zip files in "Input" folder.

2. Execute "sign-zip.bat" and  wait for completion.

3. Your signed zip files will be in "Output" folder and the md5 checksums will be stored in a file named "md5.txt".

Enjoy! ;) 
CHANDU @ GEEKOFIA 2017


